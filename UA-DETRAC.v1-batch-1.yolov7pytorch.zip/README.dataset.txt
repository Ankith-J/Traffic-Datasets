# UA-DETRAC > Batch 1
https://universe.roboflow.com/cs474-ug2-vehicle-detection/ua-detrac-rvwkg

Provided by a Roboflow user
License: CC BY 4.0

